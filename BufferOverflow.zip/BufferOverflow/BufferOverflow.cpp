// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <cstring>      // ADDED: Used for strlen to check input Length.
#include <limits>       // ADDED: Used with std::cin.ignore() to safely clear extra input.

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // CHANGED:
  // Limit input to 19 characters so there is room for the null terminator.
  // This prevents input from writing past the end of the user_input buffer.
  std::cin >> std::setw(20) >> user_input;

  // ADDED:
  // If the input filled the buffer and more characters remain,
  // notify the user and clear the remaining input from the stream.
  if (std::strlen(user_input) == 19 && std::cin.peek() != '\n')
  {
      std::cout << "Input was too long. Extra characters were blocked to prevent buffer overflow." << std::endl;
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
