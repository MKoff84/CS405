// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Modified for CS 405 Module One Numeric Overflow Activity.

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <optional>     // std::optional
#include <typeinfo>     // typeid

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// This secure version detects overflow before each addition. If the next
/// addition would exceed the maximum value for type T, std::nullopt is returned
/// so the caller can report failure without allowing wraparound or unsafe output.
/// </summary>
template <typename T>
std::optional<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check before adding. This prevents integer wraparound and floating-point overflow.
        if (increment > 0 && result > (std::numeric_limits<T>::max() - increment))
        {
            return std::nullopt;
        }

        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (decrement * steps)
/// This secure version detects underflow before each subtraction. For this
/// banking-style activity, underflow means the calculation would go below zero.
/// Returning std::nullopt communicates failure back to the test function.
/// </summary>
template <typename T>
std::optional<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check before subtracting to prevent the value from going below zero.
        // This works for unsigned, signed, character, and floating-point test types.
        if (decrement > 0 && result < decrement)
        {
            return std::nullopt;
        }

        result -= decrement;
    }

    return result;
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto result = add_numbers<T>(start, increment, steps);
    std::cout << "overflow: " << std::boolalpha << !result.has_value() << ", result: ";
    if (result.has_value())
    {
        std::cout << +result.value();
    }
    else
    {
        std::cout << "calculation prevented";
    }
    std::cout << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    std::cout << "overflow: " << std::boolalpha << !result.has_value() << ", result: ";
    if (result.has_value())
    {
        std::cout << +result.value();
    }
    else
    {
        std::cout << "calculation prevented";
    }
    std::cout << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);
    std::cout << "underflow: " << std::boolalpha << !result.has_value() << ", result: ";
    if (result.has_value())
    {
        std::cout << +result.value();
    }
    else
    {
        std::cout << "calculation prevented";
    }
    std::cout << std::endl;

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    std::cout << "underflow: " << std::boolalpha << !result.has_value() << ", result: ";
    if (result.has_value())
    {
        std::cout << +result.value();
    }
    else
    {
        std::cout << "calculation prevented";
    }
    std::cout << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}
